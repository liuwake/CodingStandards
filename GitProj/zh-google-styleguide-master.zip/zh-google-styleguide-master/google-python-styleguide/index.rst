扉页
================================

:版本: 2.59

:原作者:
    .. line-block::

        Amit Patel
        Antoine Picard
        Eugene Jhong
        Jeremy Hylton
        Matt Smart
        Mike Shields

:翻译:
    .. line-block::

        `guoqiao <http://guoqiao.me/>`_ v2.19
        `xuxinkun <https://github.com/xuxinkun>`_ v2.59

:项目主页:
    - `Google Style Guide <https://github.com/google/styleguide>`_
    - `Google 开源项目风格指南 - 中文版 <http://github.com/zh-google-styleguide/zh-google-styleguide>`_

