CSS元规则
===========

分段规则
----------

组的分段由一段注释完成（可选）。

尽可能地用注释来将css分段，段与段之间采用新行。

.. code-block:: css

  /* Header */
  
  #adw-header {}
  
  /* Footer */
  
  #adw-footer {}
  
  /* Gallery */
  
  .adw-gallery {}
