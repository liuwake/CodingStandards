扉页
===============================

:版本:    1.26

:原作者:

    .. line-block::

        Paul Armstrong
        等等

:翻译:

    .. line-block::

        `Bean Zhang <http://87boy.me/>`_ v1.26

:项目主页:

    - `Google Style Guide <https://github.com/google/styleguide>`_
    - `Google 开源项目风格指南 - 中文版 <http://github.com/zh-google-styleguide/zh-google-styleguide>`_

